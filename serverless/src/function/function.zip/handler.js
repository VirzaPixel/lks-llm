const {
   createConversation,
   updateConversation,
   getAllConversations,
   getConversationById,
   deleteConversationById,
   deleteAllConversations,
} = require("./controller");

exports.handler = async (event, context) => {
   context.callbackWaitsForEmptyEventLoop = false;

   try {
      // 1. Log event for debugging
      console.log("Incoming event:", JSON.stringify(event));

      // 2. Determine the real Intent (Method, Path, Params)
      // This allows supporting BOTH AWS Proxy and our "Manual Wrap" from frontend
      let method = event.httpMethod;
      let params = event.pathParameters || {};
      let rawBody = event.body;
      let bodyData = {};

      // If it's a POST and looks like our wrapped payload, unwrap it
      if (method === "POST" && rawBody) {
         try {
            const parsed = typeof rawBody === "string" ? JSON.parse(rawBody) : rawBody;
            if (parsed.httpMethod) {
               console.log("Detected WRAPPED event. Unwrapping...");
               method = parsed.httpMethod;
               params = parsed.pathParameters || params;
               rawBody = parsed.body;
            }
         } catch (e) {
            // Not a JSON body or not our wrap, continue with rawBody
         }
      }

      // Parse final body if present
      if (rawBody) {
         bodyData = typeof rawBody === "string" ? JSON.parse(rawBody) : rawBody;
      }

      // 3. Extract IDs (uid/id)
      const uid = params.uid || bodyData.userId || bodyData.uid;
      const id = params.id || bodyData.id;

      console.log(`Routing: ${method} | UID: ${uid} | ID: ${id}`);

      // 4. Route
      switch (method) {
         case "GET":
            if (uid && !id) return await getAllConversations(uid);
            if (uid && id) return await getConversationById(id);
            break;

         case "POST":
            if (uid) {
               bodyData.userId = uid;
               return await createConversation(bodyData);
            }
            break;

         case "PUT":
            if (id) return await updateConversation(id, bodyData);
            break;

         case "DELETE":
            if (uid && !id) return await deleteAllConversations(uid);
            if (id) return await deleteConversationById(id);
            break;
      }

      return resBody(400, {
         status: "error",
         message: `Unsupported request or missing parameters. Method: ${method}, UID: ${uid}`,
      });

   } catch (error) {
      console.error("CRITICAL HANDLER ERROR:", error);
      return resBody(500, {
         status: "error",
         message: "Lambda Internal Server Error",
         error: error.message
      });
   }
};
