const getPg = () => {
   try {
      return require("/opt/node_modules/pg");
   } catch (e) {
      try {
         return require("pg");
      } catch (e2) {
         console.error("Critical: 'pg' module not found in /opt or local node_modules");
         throw new Error("Database driver missing");
      }
   }
};

const { Pool } = getPg();

let pool;

const createPool = () => {
   return new Pool({
      user: process.env.DB_USER,
      host: process.env.DB_HOST,
      database: process.env.DB_NAME,
      password: process.env.DB_PASSWORD,
      port: parseInt(process.env.DB_PORT || "5432"),
      ssl: {
         rejectUnauthorized: false,
      },
      max: 1,
      connectionTimeoutMillis: 5000,
      idleTimeoutMillis: 30000,
   });
};

const checkPgVectorExtension = async (client) => {
   try {
      await client.query("CREATE EXTENSION IF NOT EXISTS vector");
      console.log("pgvector extension check/install successful");
   } catch (e) {
      console.warn("Could not install pgvector extension. Ensure your DB user has permission or extension is pre-installed.", e.message);
   }
};

const createTablesIfNotExist = async (client) => {
   // 1. Create table if not exists
   await client.query(`
    CREATE TABLE IF NOT EXISTS conversations (
      id UUID PRIMARY KEY,
      title TEXT NOT NULL,
      conversation JSONB NOT NULL,
      user_id UUID NOT NULL,
      "createdAt" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
      "updatedAt" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    )
  `);

   // 2. Add embedding column if missing (migration)
   try {
      await client.query(`ALTER TABLE conversations ADD COLUMN IF NOT EXISTS embedding vector(768)`);
      console.log("Migration: embedding column ensured");
   } catch (e) {
      console.warn("Migration warning: Could not add vector column. Maybe pgvector is missing?", e.message);
      // Fallback: try adding as JSONB if vector fails
      try {
         await client.query(`ALTER TABLE conversations ADD COLUMN IF NOT EXISTS embedding JSONB`);
      } catch (e2) { }
   }

   console.log("Database schema check completed");
};

const getDb = async () => {
   if (!pool) {
      pool = createPool();
   }

   try {
      const client = await pool.connect();
      console.log("Successfully connected to the database");

      await checkPgVectorExtension(client);
      await createTablesIfNotExist(client);

      client.release();
      return pool;
   } catch (error) {
      console.error("DB Connection Error:", error.message);
      throw error;
   }
};

module.exports = {
   query: async (text, params) => {
      const db = await getDb();
      return db.query(text, params);
   },
   getDb,
};
